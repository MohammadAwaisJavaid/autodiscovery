<?php

namespace OSS_SNMP\MIBS;

/**
 * A class for performing SNMP V2 queries on Huawei
 *
 */
class Huawei extends \OSS_SNMP\MIB
{

}
