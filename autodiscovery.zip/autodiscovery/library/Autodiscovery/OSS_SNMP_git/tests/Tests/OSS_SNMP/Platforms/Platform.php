<?php
/**
 * Created by PhpStorm.
 * User: barryo
 * Date: 18/04/2017
 * Time: 14:07
 */

namespace Tests\OSS_SNMP\Platforms;

use PHPUnit\Framework\TestCase;

class Platform extends TestCase
{
}