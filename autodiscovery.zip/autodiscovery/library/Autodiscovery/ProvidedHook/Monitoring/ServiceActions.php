<?php

namespace Icinga\Module\Autodiscovery\ProvidedHook\Monitoring;

use Icinga\Module\Monitoring\Hook\ServiceActionsHook;
use Icinga\Module\Monitoring\Object\Service;
use Icinga\Web\Navigation\Navigation;
use Icinga\Web\Navigation\NavigationItem;
use Icinga\Web\Url;

class ServiceActions extends ServiceActionsHook
{
    public function getActionsForService(Service $service)
    {
        $nav = new Navigation();

        $service->fetchCustomvars();
        if ($service->getName() == 'NeighborList-CDP' || $service->getName() == 'NeighborList-LLDP') {
            $nav->addItem(new NavigationItem(t('Show Topology'), array(
                'url' => Url::fromPath('autodiscovery/formtest/cdplldpdevicesearch/', array('showHost' => $service->host_name . "!" . $service->host_address, 'servicename' => $service->getName())),
                'target' => '_next',
            )));

        }

        return $nav;
    }
}
