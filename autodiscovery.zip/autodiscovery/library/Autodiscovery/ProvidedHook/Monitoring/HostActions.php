<?php

namespace Icinga\Module\Autodiscovery\ProvidedHook\Monitoring;

use Icinga\Module\Monitoring\DataView\Customvar;
use Icinga\Web\Controller\ModuleActionController;
use Icinga\Module\Monitoring\Hook\HostActionsHook;
use Icinga\Module\Monitoring\Object\Host;
use Icinga\Web\Navigation\Navigation;
use Icinga\Web\Navigation\NavigationItem;
use Icinga\Web\Url;

class HostActions extends HostActionsHook
{
    public function getActionsForHost(Host $host)
    {
        $nav = new Navigation();

        $host->fetchCustomvars();
            $nav->addItem(new NavigationItem(t('Rediscover'), array(
                'url' => Url::fromPath('autodiscovery/formtest/devicesearch/', array('showHost' => $host->getName())),
                'target' => '_next',
            )));

        return $nav;
    }
}
