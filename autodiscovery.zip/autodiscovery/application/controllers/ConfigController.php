<?php

namespace Icinga\Module\Autodiscovery\Controllers;

use Icinga\Module\Autodiscovery\Forms\Config\BackendForm;
use Icinga\Web\Controller;

class ConfigController extends Controller
{
    public function init()
    {
        $this->assertPermission('config/modules');
        parent::init();
    }

    public function backendAction()
    {
        $this->view->form = $form = new BackendForm();
        $form->setIniConfig($this->Config())->handleRequest();
        $this->view->tabs = $this->Module()->getConfigTabs()->activate('backend');
    }
}