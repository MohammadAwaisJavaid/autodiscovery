<?php
namespace Icinga\Module\Autodiscovery\Controllers;

use Icinga\Application\Config;
use Icinga\Module\Autodiscovery\Forms\MyForm2;
use Icinga\Module\Autodiscovery\Forms\MyForm;
use Icinga\Module\Autodiscovery\Forms\MyForm3;
use Icinga\Module\Autodiscovery\Forms\MyForm4;
use Icinga\Module\Autodiscovery\OSS_SNMP\SNMP;
use Icinga\Module\Director\Db;
use Icinga\Module\Director\Web\Controller\ActionController;
use Icinga\Module\Monitoring\Web\Rest\RestRequest;
use Icinga\Util\Json;
//use Icinga\Application\Logger;
use Icinga\Web\Form;
//use Icinga\Module\Autodiscovery\OSS_SNMP\Exception;
use \SNMP as ss;
use \Exception;
use RuntimeException;
use Icinga\Module\Monitoring\Backend;
use Icinga\Web\Controller;

class FormtestController extends Controller {
    private $db;
    private $monitoring;
    #Fasiha: OIDs for device rediscovery feature
    public $oid_sysObjectID = '1.3.6.1.2.1.1.2.0';
    // system object id
    public $oid_sysDescr = '1.3.6.1.2.1.1.1.0';
    //system description
    public $oid_sysName = '1.3.6.1.2.1.1.5.0';
    //system name
    public $oid_sysUpTime = '1.3.6.1.2.1.1.3.0';
    //system uptime
    public $oid_sysLocation = '1.3.6.1.2.1.1.6.0';
    //system location
    public $oid_sysContact = '1.3.6.1.2.1.1.4.0';
    //system contact

    public $oid_cisco_ChassisModel     = '1.3.6.1.4.1.9.5.1.2.16.0';
    public $oid_cisco_ChassisSrNumStr  = '1.3.6.1.4.1.9.5.1.2.19.0';
    public $oid_cisco_model            = '1.3.6.1.2.1.47.1.1.1.1.13.1';
    public $oid_cisco_serial           = '1.3.6.1.2.1.47.1.1.1.1.11.1';
    public $oid_cisco_vmVlan           = '1.3.6.1.4.1.9.9.68.1.2.2.1.2';
    public $oid_cisco_whyreload        = '1.3.6.1.4.1.9.2.1.2.0';
    public $oid_software_revision      = '1.3.6.1.2.1.47.1.1.1.1.10.1';
    public $oid_sw_rev                 = '1.3.6.1.2.1.47.1.1.1.1.10.1001';

    public $oid_cisco_switch_model     = '1.3.6.1.2.1.47.1.1.1.1.13.149';
    public $oid_cisco_switch_serial    = '1.3.6.1.2.1.47.1.1.1.1.11.149';
    public $oid_cisco_switch_software_revision = '1.3.6.1.2.1.47.1.1.1.1.10.22';

    public $oid_emerson_model = '1.3.6.1.4.1.13400.2.19.1.2.0';
    public $oid_emerson_make = '1.3.6.1.4.1.13400.2.19.1.1.0';

    public $oid_apc_ups_model     = '1.3.6.1.4.1.318.1.1.1.1.1.1.0';
    public $oid_apc_ups_serial    = '1.3.6.1.4.1.318.1.1.1.1.2.3.0';
    public $oid_apc_ups_firmware_revision = '1.3.6.1.4.1.318.1.1.1.1.2.1.0';

    public $oid_apc_pdu_model     = '1.3.6.1.4.1.318.1.1.12.1.5.0';
    public $oid_apc_pdu_serial    = '1.3.6.1.4.1.318.1.1.12.1.6.0';
    public $oid_apc_pdu_firmware_revision = '1.3.6.1.4.1.318.1.1.12.1.3.0';

    public $oid_juniper_model = '1.3.6.1.4.1.2636.3.1.2.0';
    public $oid_juniper_version = '1.3.6.1.2.1.25.6.3.1.2.2';
    public $oid_juniper_serial = '1.3.6.1.4.1.2636.3.1.3.0';

    public $oid_huawei_model = '1.3.6.1.4.1.2011.2.6.7.1.1.2.1.7.0.0';
    public $oid_huawei_version = '1.3.6.1.4.1.2011.5.25.19.1.4.2.1.5.1';
    public $oid_huawei_serial = '1.3.6.1.2.1.47.1.1.1.1.11.9';

    public $oid_fortinet_version = '1.3.6.1.4.1.12356.101.4.1.1.0';
    public $oid_fortinet_serial = '1.3.6.1.4.1.12356.100.1.1.1.0';

    public $oid_raisecom_model = '1.3.6.1.4.1.8886.6.1.1.1.19.0';
    public $oid_raisecom_version = '1.3.6.1.4.1.8886.6.1.1.1.16.0';
    public $oid_raisecom_serial = '1.3.6.1.4.1.8886.6.1.1.1.14.0';

    public $oid_ruckus_model = '1.3.6.1.4.1.25053.1.2.1.1.1.1.9';
    public $oid_ruckus_version = '1.3.6.1.4.1.25053.1.2.1.1.1.1.18';
    public $oid_ruckus_serial = '1.3.6.1.4.1.25053.1.2.1.1.1.1.15';

    public $oid_brocade_model = '1.3.6.1.2.1.47.1.1.1.1.2.1';
    public $oid_brocade_version = '1.3.6.1.4.1.1588.2.1.1.1.1.6.0';
    public $oid_brocade_serial = '1.3.6.1.2.1.47.1.1.1.1.11.1';

    public $oid_netgear_model = '1.3.6.1.4.1.4526.10.1.1.1.3.0';
    public $oid_netgear_version = '1.3.6.1.4.1.4526.10.1.1.1.13';
    public $oid_netgear_serial = '1.3.6.1.4.1.4526.10.1.1.1.4.0';
    
    public $oid_hp_model = '.1.3.6.1.2.1.1.1.0';
    public $oid_hp_version = '.1.3.6.1.4.1.11.2.36.1.1.2.6.0 ';
    public $oid_hp_serial = '.1.3.6.1.4.1.11.2.36.1.1.2.9.0';
    

    public $interfaceAction_host = null;

    //autodiscovery form

    public function indexAction() {
        $form = new MyForm();
        $form->setup();
        $this->view->form = $form;
    }

    //autodiscovery snmpform

    public function snmp2Action() {
        $form = new MyForm2();
        $form->setup();
        $this->view->form = $form;
    }

    //search form

    public function searchAction() {
        $dbResourceName = Config::module( 'director' )->get( 'db', 'resource' );
        $connection = Db::fromResourceName( $dbResourceName );
        $db = $connection->getDbAdapter();
        $sql = 'SELECT id,object_name from icinga_host where object_type =?';
        $this->view->result = $db->fetchAll( $sql, 'template' );
        // $oid = '.1.3.6.1.2.1.1.5.0';
        //host id

        //Scan the network with nmap for a list of live hosts, then render a form, to be selected by user
        if ( isset( $_POST['version_type'] ) ) {
            $version = $_POST['version_type'];
            if ( $version == 'v2' || $version == 'v1' ) {
                $ip = $_POST['ip'].'/28';
                $comm = $_POST['comm'];
                $output = shell_exec( 'nmap -sP  ' . $ip );
                preg_match_all( '/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/', $output, $ip_matches );
                $oid = '.1.3.6.1.2.1.1.5.0';
                //host id
                $hostname = '';
                $community = $comm;
		$arr = array();
//		print_r($ip_matches);
              foreach ( $ip_matches[0] as $index => $ip ) {
                    if ( $version == 'v2' ) {
                        $session = new ss( ss::VERSION_2c, $ip, $community );
                        //$ip_matches[0][$i]
                    } else if ( $version == 'v1' ) {
                        $session = new ss( ss::VERSION_1, $ip, $community );
                        //$ip_matches[0][$i]
//                        $ret = @$session->get( $oid );
                    }
//try {
	$ret = @$session->get( $oid );
//	print_r($ret);
	if ( $ret != false ) {
		                        $arr[$ip] = str_replace( 'STRING: ', '', $ret );
					                        $arr[$ip] = str_replace( '"', '', $arr[$ip] );
					                    }
	                    else {
	                                          unset( $ip_matches[0][$index] );
	                                                              }
	
//}
//catch(Exception $e) {
//print $e;
//}

    $error = $session->getError();
	  
		    if ( $ret != false ) {
                        $arr[$ip] = str_replace( 'STRING: ', '', $ret );
                        $arr[$ip] = str_replace( '"', '', $arr[$ip] );
                    }
                    //$ip_matches[0][$i]
                    else {
                        unset( $ip_matches[0][$index] );
		    }
	      }
                $this->view->ip_matches = $ip_matches[0];
                $this->view->arr = $arr;
                $this->view->community = $community;
                $this->view->version = $version;
//		return;
	        } else if ( $version == 'v3' ) {

                $ip = $_POST['ip'].'/24';
                $username = $_POST['username'];
                $level = $_POST['level'];
                $authtype = $_POST['authtype'];
                $privtype = $_POST['privtype'];
                $authpass = $_POST['authpass'];
                $privpass = $_POST['privpass'];
                $output = shell_exec( 'nmap -sP  ' . $ip );
                preg_match_all( '/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/', $output, $ip_matches );
                $oid = '.1.3.6.1.2.1.1.5.0';
                //host id
                $arr = array();
                foreach ( $ip_matches[0] as $index => $ip ) {

                    $session = new ss( ss::VERSION_3, $ip, $username );
                    $session->setSecurity( $level, $authtype, $authpass, $privtype, $privpass, '', '' );
                    $ret = @$session->get( $oid );
                    $error = $session->getError();
                    if ( $ret != false ) {
                        $arr[$ip] = str_replace( 'STRING: ', '', $ret );
                        $arr[$ip] = str_replace( '"', '', $arr[$ip] );
                    } else {
                        unset( $ip_matches[0][$index] );
                    }
                }
                $this->view->ip_matches = $ip_matches[0];
                $this->view->username = $username;
                $this->view->version = $version;
                $this->view->level = $level;
                $this->view->authtype = $authtype;
                $this->view->authpass = $authpass;
                $this->view->privtype = $privtype;
                $this->view->privpass = $privpass;
                $this->view->arr = $arr;
                return;
            }
        }

    }

    //snmp search form

    public function search2Action() {
        if ( isset( $_POST['ip'] ) ) {
            $ip = $_POST['ip'];
            $comm = $_POST['comm'];
            //nmap
            $output = shell_exec( 'nmap -sP  ' . $ip );
            //tokenization
            preg_match_all( '/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/', $output, $ip_matches );
            echo $output . '</br>';
        }
    }

    //main add action

    public function addhostAction() {
        $version = $_POST['version'];
        if ( $version == 'v2' || $version == 'v1' ) {
            //$data = $this->getRequest()->getParams();
            $hosts = [];

            // only add host if post
            if ( $this->getRequest()->isPost() ) {
                foreach ( $_POST['chosen'] as $key => $value ) {
                    array_push( $hosts, ['ipaddress' => $_POST['ipaddress'][$key], 'hostname' => $_POST['hostname'][$key], 'community' => $_POST['community'][$key], 'host_template' => $_POST['host_template'][$key], 'chosen' => $_POST['chosen'][$key]] );
                }
            }
            foreach ( $hosts as $x ) {
                $this->addhost( $x['ipaddress'], $x['hostname'], $x['host_template'], $version, $x['community'], null, null, null, null, null, null );
                //Only add host, as interfaces will be added in autodiscovery
                // $this->interfaceAction( $x['ipaddress'], $x['hostname'] );
            }
        } else if ( $version == 'v3' ) {
            $hosts = [];
            if ( $this->getRequest()->isPost() ) {
                foreach ( $_POST['chosen'] as $key => $value ) {
                    array_push( $hosts, ['ipaddress' => $_POST['ipaddress'][$key],
                    'hostname' => $_POST['hostname'][$key],
                    'username' => $_POST['username'][$key],
                    'host_template' => $_POST['host_template'][$key],
                    'chosen' => $_POST['chosen'][$key],
                    'level' => $_POST['level'][$key],
                    'authtype' => $_POST['authtype'][$key],
                    'authpass' => $_POST['authpass'][$key],
                    'privtype' => $_POST['privtype'][$key],
                    'privpass' => $_POST['privpass'][$key]] );
                }

            }
            foreach ( $hosts as $x ) {
                $this->addhost( $x['ipaddress'], $x['hostname'], $x['host_template'], $version, null, $x['username'], $x['level'], $x['authtype'], $x['authpass'], $x['privtype'], $x['privpass'] );
            }
        }
    }

    // Api Works

    public function addhost( $ip, $hostname, $imports, $version, $community, $username, $level, $authtype, $authpass, $privtype, $privpass ) {
        if ( $version == 'v2' || $version == 'v1' ) {
            $url = $this->Config()->get( 'director', 'url' );
            $rq = RestRequest::post( "$url/director/host" );
            //authentication username and password
            $rq->authenticateWith( $this->Config()->get( 'director', 'user' ), $this->Config()->get( 'director', 'password' ) );
            $mypayload = array(
                'address' => $ip,
                'imports' => $imports,
                'object_name' => $hostname,
                'object_type' => 'object',
                'vars.snmp_community' => $community,
                'vars.snmp_version' => '-2',
            );
            $mypayload = Json::encode( $mypayload, true );
            $rq->setPayload( $mypayload );
            $result = $rq->send();
        } else if ( $version == 'v3' ) {
            $url = $this->Config()->get( 'director', 'url' );
            $rq = RestRequest::post( "$url/director/host" );
            //authentication username and password
            $rq->authenticateWith( $this->Config()->get( 'director', 'user' ), $this->Config()->get( 'director', 'password' ) );
            $mypayload = array(
                'address' => $ip,
                'imports' => $imports,
                'object_name' => $hostname,
                'object_type' => 'object',
                'vars.snmp_version' => '-3',
                'vars.username' => $username,
                'vars.level' => $level,
                'vars.authtype' => $authtype,
                'vars.authpass' => $authpass,
                'vars.privtype' => $privtype,
                'vars.privpass' => $privpass,
            );
            $mypayload = Json::encode( $mypayload, true );
            $rq->setPayload( $mypayload );
            $result = $rq->send();

        }
        //error if hosts already exits
        if ( isset( $result['error'] ) ) {
            $pattern = ' /Trying to recreate icinga_host (.+)/';
            $success = preg_match( $pattern, $result['error'], $match );
            if ( $success ) {
                echo '<h1> Error! </h1>';
                echo "</br><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; A host with name $match[1] already exists.</b></br>";
            }
        }
        //successfully added host
        else {
            echo '<h1> Success! </h1>';
            echo "&nbsp; Successfully created host <b>Hostname: $hostname IP Address: $ip Template: $imports</b><br/>";
        }

    }

    //tokenize

    private function tokenizeString( $string, $delimeter = '\/' ) {
        $token = strtok( $string, $delimeter );
        $arr = array();
        while ( $token !== false ) {
            array_push( $arr, $token );
            // echo "$token\n";
            $token = strtok( '\/' );
        }
        return $arr;
    }

    public function interfaceserviceAction() {
        $data = $this->getRequest()->getParams();
        $host_id = $data['host_id'];
        echo $this->interfaceAction_host;

        //add interfaces for host, for each selected interface
        foreach ( $data['checked_interfaces'] as $iface ) {
            $this->createInterfaceService( $data['hostname'], $iface );
        }
        return;
    }
    // list a table of interfaces for host
    //only called from web

    public function interfaceAction( $ip = null, $hostname = null ) {
        $ip_arr = array();
        #Maham: Added iname array for comparing added interfaces
        $iname = [];
        //get list of hosts that provide snmp
        $dbResourceName = Config::module( 'director' )->get( 'db', 'resource' );
        $connection = Db::fromResourceName( $dbResourceName );
        $db = $connection->getDbAdapter();
        $sql = 'select id, object_name, display_name, address , cv.varname, cv.varvalue  
                from icinga_host h  
                inner join icinga_host_var cv on h.id=cv.host_id   
                where h.object_type=? and cv.varname=?';
        $hosts = $db->fetchAll( $sql, ['object', 'snmp_version'] );

        $this->view->hosts = $hosts;
        if ( $this->getRequest()->isPost() ) {
            $data = $this->getRequest()->getParams();
            $object = unserialize( $data['host'] );
            $this->interfaceAction_host = $object->id;
            $address = $object->address;
            $objectid = $object->id;
            $objectname = $object->object_name;
            $address_arr = explode( ',', $address );
            if ( $object->varvalue == -1 || $object->varvalue == -2 ) {
                $sql = "select ih.varvalue as 'community' 
                    from icinga_host h
                    inner join icinga_host_var ih on ih.host_id = h.id
                    where ih.varname = 'snmp_community' and id =  $objectid";

                $hosts = $db->fetchAll( $sql );
                if ( $hosts != null ) {
                    $community = $hosts[0]->community;
                    try {
                        $snmpHost = new SNMP( $address_arr[0], $community );
                    } catch( Exception $e ) {
                        $snmpHost = new SNMP( $address_arr[1], $community );
                    }
                }
            } else if ( $object->varvalue == -3 ) {
                $sql = "select ih.varvalue as 'username', ih2.varvalue as 'level',
                        ih3.varvalue as 'authtype',
                        ih4.varvalue as 'authpass',
                        ih5.varvalue as 'privtype',
                        ih6.varvalue as 'privpass'
                        from icinga_host h
                        inner join icinga_host_var ih on ih.host_id = h.id
                        inner join icinga_host_var ih2 on ih2.host_id = h.id
                        inner join icinga_host_var ih3 on ih2.host_id = h.id
                        inner join icinga_host_var ih4 on ih2.host_id = h.id
                        inner join icinga_host_var ih5 on ih2.host_id = h.id
                        inner join icinga_host_var ih6 on ih2.host_id = h.id
                        where ih.varname = 'username' and ih2.varname = 'level' and ih3.varname = 'authtype' 
                        and ih4.varname = 'authpass' and ih5.varname ='privtype' and ih6.varname = 'privpass'
                        and h.id = $objectid";

                $hosts = $db->fetchAll( $sql );

                if ( $hosts != null )
                try {
                    $snmpHost = new SNMP( $address_arr[0], $hosts[0]->username, 3, $hosts[0]->level, $hosts[0]->authtype, $hosts[0]->authpass, $hosts[0]->privtype, $hosts[0]->privpass );

                } catch( Exception $e ) {
                    $snmpHost = new SNMP( $address_arr[1], $hosts[0]->username, 3, $hosts[0]->level, $hosts[0]->authtype, $hosts[0]->authpass, $hosts[0]->privtype, $hosts[0]->privpass );

                }
            }
            #Maham: Added query and populated data in iname array
            $sql = "select v.varvalue
                      from icinga_service s
                        inner join icinga_service_var v on v.service_id = s.id
                        where v.varname = 'snmp_interface' and s.host_id = $objectid";

            $iname = $db->fetchAll( $sql );
            $inameArray =  array();
            foreach ( $iname as $value ) {
                array_push( $inameArray, $value->varvalue );
            }
            try {
                $phys_name  = $snmpHost->useIface()->names();
		$phys_desc  = $snmpHost->useIface()->descriptions();
                $phys_state = $snmpHost->useIface()->operationStates( true );
                //$phys_ip    = $snmpHost->useIp()->ipAddressIndexList();

                //foreach($phys_ip as $k=>$v)
                //{
                  // $ip_arr[$v] = $k;   
               // }
                echo '<form name="test_table" method="post" action="autodiscovery/formtest/interfaceservice" class="autofocus" style="margin-bottom: 153.2px;">';
                echo '<h2>&nbsp;The Interface names for ' . $object->object_name . ' are </br></h2>';
                echo "<input type='hidden' name='host_id' value='" . $object->id . "'>";
                echo "<input type='hidden' name='hostname' value='" . $object->object_name . "'>";
                echo "<input type='hidden' name='host_ip' value='" . $object->address . "'>";
                echo "<table border='1' style='margin-left: 50px'><br />";
                echo '<th>Vlan ID</th>';
                echo '<th>Interface Name</th>';
               // echo '<th>Interface IP</th>';
                echo '<th>Interface Description</th>';
                echo '<th>Operation State</th>';

                //onclick checkAll
                echo "<th><input type='checkbox' id='checkall'  onClick='check_uncheck_checkbox(this.checked);'/>Select Interface</th>";
                //<td>','<input type = 'checkbox' name = 'checked_interfaces['.$hostname.'][]' value = '".$value."'>','</td>
                if ( isset( $phys_name ) ) {
                    foreach ( $phys_name as $key => $value ) {
                        echo '<tr><td>' . $key . "</td>
                      <td>" . ( isset( $value ) ? $value :'NULL' ) . "</td>
            		      <td>". ( isset( $phys_desc[$key] )? $phys_desc[$key]:'NULL' )."</td>
                     	      <td>" . $phys_state[$key]   . "</td>
                            <td>";

/*                        if ( in_array( $phys_name[$key], $inameArray ) ) {
                           echo '<input type="checkbox"  onchange="checkbox_toggled()" checked disabled name="checked_interfaces[]" value="' . $value . '">';
                        } else {
                            echo '<input type="checkbox"  onchange="checkbox_toggled()" name="checked_interfaces[]" value="' . $value . '">';
			}*/

			echo '<input type="checkbox"  onchange="checkbox_toggled()" name="checked_interfaces[]" value="' . $value . '">';
                        echo '</td></tr>';
                    }
                    echo '</table>';
                    echo "<div class='control-group form-controls'><br>
                              <input type='submit' name='btn_submit'  disabled='true'  id='Add'  value='Monitor interfaces for hosts' data-progress-label='Adding'><div class='spinner'><i aria-hidden='true' class='icon-spin6'></i></div></div>";
                    echo '</form>';
                    echo '<br>';
                } else {

                }
	    } catch( Exception $e ) {
		     print $e;
                echo '<p>&nbsp; Error: SNMP might not be enabled on the host<br/></p>';
            }

        }
    }

    //main add interface
    //Depreciated: will remove this method

/*    public function addinterfaceAction( $ip = null ) {
        $data = $this->getRequest()->getParams();
        if ( $this->getRequest()->isPost() ) {
            $interface_template_name = $this->getInterfaceServiceTemplateName();
            // loop over checked interfaces to add
            foreach ( $data['checked_interfaces'] as $x ) {
                $arr = explode( '_', $x );
                $interface = end( $arr );
                $hostname = $arr[0];
                echo '&nbsp;&nbsp;&nbsp;Interface = ' . $interface . ' and host = ' . $hostname . '</br>';

                echo '&nbsp;&nbsp;&nbsp;Interface Name = ' . $interface . '</br>';
                // $this->createInterfaceService( $hostname, $interface_template_name, $interface );
            }
            echo '</br>&nbsp;&nbsp;&nbsp;&nbsp;<button class="primary"><a href="/trace9/director/hosts" class="active">View Interface</a></button>';
        }
        // main post block
        else {
            echo 'Please submit the form again</br>';
        }

    }
*/
    // create Interface Api Service
    //Input host_id, interface_name
    //Output Creates a service fo rthe interface

    private function createInterfaceService( $hostname, $interface_name ) {
        $interface_service_template_name = 'snmp-interface-dual';
        $url = $this->Config()->get( 'director', 'url' );
        $rq = RestRequest::post( "$url/director/service" );
        //authentication username and password
        $rq->authenticateWith( $this->Config()->get( 'director', 'user' ), $this->Config()->get( 'director', 'password' ) );
        $mypayload = array(
            'host' => $hostname,
            'imports' => $interface_service_template_name,
            'object_name' => 'interface_' . $interface_name,
            'object_type' => 'object',
            'vars' => array(
                'snmp_interface' => $interface_name,
            ),
        );
        $mypayload = Json::encode( $mypayload, true );
        $rq->setPayload( $mypayload );
        try {
            $result = $rq->send();
        } catch( Exception $e ) {
            echo "&nbsp; Something went wrong: $e <br/>";
        }

        //error handling if interface exists
        if ( isset( $result['error'] ) ) {
            $pattern = ' /Trying to recreate (\S+).*":"(..)","object_name":"(.*)"}/';
            $success = preg_match( $pattern, $result['error'], $match );
            if ( $success ) {
                echo '<h1> Error! </h1>';
                echo '</br><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; The Interface is already monitored with name: '.$match[3].' and Host id: '.$match[2].'</b></br>';
                //echo '</br><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' . $result['error'] . '</b></br>';
                // print_r( $match );
            }
            // echo '</br><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' . $result['error'] . '</b></br>';
        } else {
            echo '<h1> Success! </h1>';
            echo "</br><b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            Monitoring service for interface: " . $interface_name . ' created successfully</b>';
        }
    }

    //interface template name

/*
    private function getInterfaceServiceTemplateName() {
        //not using this logic to search a template that contains 'interface' as substring
        if ( false ) {
            $rq = RestRequest::get( 'https://172.31.1.73:5665/v1/templates/services' );
            $rq->authenticateWith( 'root', '336c8cd3fd321fcf' )->noStrictSsl();
            $result = $rq->send();
            $service_templates = $result['results'];
            $found = false;
            $interface_template_name = '';
            foreach ( $service_templates as $x ) {
                $y = $x['name'];
                if ( strpos( $y, 'interface' ) !== false ) {
                    $interface_template_name = $y;
                    $found = true;
                    break;
                }
            }
            if ( $found );
            //echo '&nbsp;&nbsp;Found this template in director ='.$interface_template_name.'</br>';
            else {
                echo 'Any service template with \'interface\' as name not found</br> Please add a template first</br>';
            }

        }
        $interface_template_name = 'snmp-interface-dual';
        return $interface_template_name;
    }
*/
    //interface host name, this helper is not bein called anywhere

    public function getHostname( $ip ) {
        $url = 'https://172.31.1.73:5665/v1/objects/hosts?filter=match(%22*' . $ip . '*%22,host.address)&attrs=name';
        //print( $url );
        $rq = RestRequest::get( $url );
        //$rq->authenticateWith( 'root', 'd2229c5682efa455' )->noStrictSsl();
        $rq->authenticateWith( 'root', '336c8cd3fd321fcf' )->noStrictSsl();
        $result = $rq->send();
        return $result;
    }

    //cdp form

    public function cdpAction() {
        $form = new MyForm3();
        $form->setup();
        $this->view->form = $form;
    }

    //lldp form

    public function lldpAction() {
        $form = new MyForm4();
        $form->setup();
        $this->view->form = $form;
    }

    public function createcdpAction() {
        $neighbours = [];

        if ( $this->getRequest()->isPost() ) {
            foreach ( $_POST['chosen'] as $key => $value ) {
                //echo $_POST['device_ports'][$key];
                //echo $_POST['device_ids'][$key];
                $neighbours[$_POST['device_ports'][$key]] = $_POST['device_ids'][$key];
                // array_push( $neighbours, ['device_ports' => $_POST['device_ports'][$key], 'device_ids' => $_POST['device_ids'][$key] ] );
            }
        }

        $url = $this->Config()->get( 'director', 'url' );
        $rq = RestRequest::post( "$url/director/host" );
        //authentication username and password
        $rq->authenticateWith( $this->Config()->get( 'director', 'user' ), $this->Config()->get( 'director', 'password' ) );
        $mypayload = array(
            'host' => 'grafana01',
            'object_type' => 'object',
            'vars' => $neigbours
        );
        $mypayload = Json::encode( $mypayload, true );
        $rq->setPayload( $mypayload );
        $result = $rq->send();

        //error handling if interface exists
        if ( isset( $result['error'] ) ) {
        }

    }
    //cdp search action

    public function cdpsearchAction() {
        $dbResourceName = Config::module( 'director' )->get( 'db', 'resource' );
        $connection = Db::fromResourceName( $dbResourceName );
        $db = $connection->getDbAdapter();
        $sql = 'SELECT id,object_name from icinga_host where object_type =?';
        $this->view->result = $db->fetchAll( $sql, 'template' );
        //Scan the network with nmap for a list of live hosts, then render a form, to be selected by user
        if ( isset( $_POST['version_type'] ) ) {
            $version = $_POST['version_type'];
            $oid = '.1.3.6.1.2.1.1.6.0';
            //host id
            $oid_device_id = '.1.3.6.1.4.1.9.9.23.1.2.1.1.6';
            //device id
            $oid_device_port = '.1.3.6.1.4.1.9.9.23.1.2.1.1.7';
            //device port
            #           $oid_sys_name = '.1.3.6.1.4.1.9.9.23.1.2.1.1.17';
            //system name
            $oid_sys_cap = '1.3.6.1.4.1.9.9.23.1.2.1.1.9';
            $oid_device_ip = '.1.3.6.1.4.1.9.9.23.1.2.1.1.4';
            //device IP
            $hostname = '';

            if ( $version == 'v2' || $version == 'v1' ) {
                $ip = $_POST['ip'];
                $community = $_POST['comm'];
                if ( $version == 'v2' ) {
                    $session = new ss( ss::VERSION_2c, $ip, $community );
                    //$ip_matches[0][$i]
                } else if ( $version == 'v1' ) {
                    $session = new ss( ss::VERSION_1, $ip, $community );
                }
            } else if ( $version == 'v3' ) {
                $ip = $_POST['ip'];
                $username = $_POST['username'];
                $level = $_POST['level'];
                $authtype = $_POST['authtype'];
                $privtype = $_POST['privtype'];
                $authpass = $_POST['authpass'];
                $privpass = $_POST['privpass'];
                $session = new ss( ss::VERSION_3, $ip, $username );
                $session->setSecurity( $level, $authtype, $authpass, $privtype, $privpass, '', '' );
            }

            $ret = @$session->walk( $oid_device_id );
            if ( $ret == false ) {
                echo '<p>&nbsp; Error: No device found using  cdp protocol.<br/></p>';
                return;
            }

            $device_ids = array();
            foreach ( $ret as $k => $v ) {
                $v = str_replace( 'STRING: ', '', $v );
                $v = str_replace( '"', '', $v );
                $pattern = '/.+\.(\d+\.\d+)/';
                $string = $k;
                $success = preg_match( $pattern, $string, $matches );
                $device_ids[$matches[1]] = array();
                //$v ;
                array_push( $device_ids[$matches[1]], $v );
            }
            //$session = new ss( ss::VERSION_2c, $ip, $community );
            //$ip_matches[0][$i]
            $ret = @$session->walk( $oid_device_port );
            $device_ports = array();
            foreach ( $ret as $k => $v ) {
                $v = str_replace( 'STRING: ', '', $v );
                $v = str_replace( '"', '', $v );
                $pattern = '/.+\.(\d+\.\d+)/';
                $string = $k;
                $success = preg_match( $pattern, $string, $matches );
                array_push( $device_ids[$matches[1]], $v );
            }
            //$session = new ss( ss::VERSION_2c, $ip, $community );
            //$ip_matches[0][$i]
            /*            $ret = @$session->walk( $oid_sys_name );
            $device_ports = array();
            foreach ( $ret as $k => $v ) {
                $v = str_replace( 'STRING: ', '', $v );
                $v = str_replace( '"', '', $v );
                $pattern = '/.+\.(\d+\.\d+)/';
                $string = $k;
                $success = preg_match( $pattern, $string, $matches );
                array_push( $device_ids[$matches[1]], $v );
            }
            */
            //$session = new ss( ss::VERSION_2c, $ip, $community );
            //$ip_matches[0][$i]
            $ret = @$session->walk( $oid_device_ip );
            $device_ports = array();
            foreach ( $ret as $k => $v ) {
                $v = str_replace( 'STRING: ', '', $v );
                $v = str_replace( '"', '', $v );
                $v = str_replace( 'Hex-', '', $v );

                $str_arr = explode ( ' ', $v );

                $len = count( $str_arr );
                for ( $i = 0; $i<( $len-1 );
                $i++ ) {
                    $str_arr[$i] = hexdec( $str_arr[$i] );
                    $v = implode( ' ', $str_arr );

                }
                $v = rtrim( $v );
                $v = str_replace( ' ', '.', $v );

                $pattern = '/.+\.(\d+\.\d+)/';
                $string = $k;
                $success = preg_match( $pattern, $string, $matches );
                array_push( $device_ids[$matches[1]], $v );
            }

            /*           $ret = @$session->walk( $oid_sys_cap );
            $device_ports = array();
            foreach ( $ret as $k => $v ) {
                $v = str_replace( 'STRING: ', '', $v );
                $v = str_replace( '"', '', $v );
                $v = str_replace( 'Hex-', '', $v );
                print $v;
                $pattern = '/.+\.(\d+\.\d+)/';
                $string = $k;
                $success = preg_match( $pattern, $string, $matches );
                print_r( $device_ids[$matches[1]] );
                //               array_push( $device_ids[$matches[1]], $v );

                //print_r( $device_ids );
            }
            */

            if ( $version == 'v2' || $version == 'v1' ) {
                $this->view->matches = $matches[0];
                $this->view->device_ids = $device_ids;
                $this->view->community = $community;
                $this->view->version = $version;
                return;
            } else if ( $version == 'v3' ) {
                $this->view->matches = $matches[0];
                $this->view->device_ids = $device_ids;
                $this->view->username = $username;
                $this->view->version = $version;
                $this->view->level = $level;
                $this->view->authtype = $authtype;
                $this->view->authpass = $authpass;
                $this->view->privtype = $privtype;
                $this->view->privpass = $privpass;

                $this->view->version = $version;
                return;
            }

        }
    }

    //lldp search action

    public function lldpsearchAction() {
        $dbResourceName = Config::module( 'director' )->get( 'db', 'resource' );
        $connection = Db::fromResourceName( $dbResourceName );
        $db = $connection->getDbAdapter();
        $sql = 'SELECT id,object_name from icinga_host where object_type =?';
        $this->view->result = $db->fetchAll( $sql, 'template' );
        //Scan the network with nmap for a list of live hosts, then render a form, to be selected by user
        $oid = '.1.3.6.1.2.1.1.6.0';
        //host id
        $oid_port_id = '.1.0.8802.1.1.2.1.4.1.1.7';
        //device id
        $oid_port_desc = '.1.0.8802.1.1.2.1.4.1.1.8';
        //device port
        $oid_sys_name = '.1.0.8802.1.1.2.1.4.1.1.9';
        //system name
        $oid_sys_cap = '.1.0.8802.1.1.2.1.4.1.1.11';
        //device IP
        $hostname = '';
        if ( isset( $_POST['version_type'] ) ) {
            $version = $_POST['version_type'];

            if ( $version == 'v2' || $version == 'v1' ) {
                $ip = $_POST['ip'];
                $community = $_POST['comm'];
                if ( $version == 'v2' ) {
                    $session = new ss( ss::VERSION_2c, $ip, $community );
                    //$ip_matches[0][$i]
                } else if ( $version == 'v1' ) {
                    $session = new ss( ss::VERSION_1, $ip, $community );
                }
            } else if ( $version == 'v3' ) {
                $ip = $_POST['ip'];
                $username = $_POST['username'];
                $level = $_POST['level'];
                $authtype = $_POST['authtype'];
                $privtype = $_POST['privtype'];
                $authpass = $_POST['authpass'];
                $privpass = $_POST['privpass'];
                $session = new ss( ss::VERSION_3, $ip, $username );
                $session->setSecurity( $level, $authtype, $authpass, $privtype, $privpass, '', '' );
            }

            $ret = @$session->walk( $oid_port_id );
            if ( $ret == false ) {
                echo '<p>&nbsp; Error: No device found using  lldp protocol.<br/></p>';
                return;
            }
            $device_ids = array();
            if ( sizeOf( $ret ) >0 )
            foreach ( $ret as $k => $v ) {
                $v = str_replace( 'STRING: ', '', $v );
                $v = str_replace( '"', '', $v );
                $v = str_replace( 'Hex-', '', $v );
                $pattern = '/.+\.(\d+\.\d+)/';
                $string = $k;
                //echo $k;
                $success = preg_match( $pattern, $string, $matches );
                $device_ids[$matches[1]] = array();
                //$v ;
                //echo "\n $v \n";
                array_push( $device_ids[$matches[1]], $v );
                // print_r( $device_ids );
            }

            $ret = @$session->walk( $oid_port_desc );
            $device_ports = array();
            if ( sizeOf( $ret ) >0 )
            foreach ( $ret as $k => $v ) {
                $v = str_replace( 'STRING: ', '', $v );
                $v = str_replace( '"', '', $v );
                $pattern = '/.+\.(\d+\.\d+)/';
                $string = $k;
                $success = preg_match( $pattern, $string, $matches );
                array_push( $device_ids[$matches[1]], $v );

                //print_r( $device_ids );
            }

            $ret = @$session->walk( $oid_sys_name );
            $device_ports = array();
            if ( sizeOf( $ret ) >0 )
            foreach ( $ret as $k => $v ) {
                $v = str_replace( 'STRING: ', '', $v );
                $v = str_replace( '"', '', $v );
                $pattern = '/.+\.(\d+\.\d+)/';
                $string = $k;
                $success = preg_match( $pattern, $string, $matches );
                array_push( $device_ids[$matches[1]], $v );

                //print_r( $device_ids );
            }

            $ret = @$session->walk( $oid_sys_cap );
            $device_ports = array();
            if ( sizeOf( $ret ) >0 )
            foreach ( $ret as $k => $v ) {
                $v = str_replace( 'STRING: ', '', $v );
                $v = str_replace( '"', '', $v );
                $v = str_replace( 'Hex-', '', $v );
                $pattern = '/.+\.(\d+\.\d+)/';
                $string = $k;
                $success = preg_match( $pattern, $string, $matches );
                array_push( $device_ids[$matches[1]], $v );

                //print_r( $device_ids );
            }

            if ( $version == 'v2' || $version == 'v1' ) {
                $this->view->matches = $matches[0];
                $this->view->device_ids = $device_ids;
                $this->view->community = $community;
                $this->view->version = $version;
                return;
            } else if ( $version == 'v3' ) {
                $this->view->matches = $matches[0];
                $this->view->device_ids = $device_ids;
                $this->view->username = $username;
                $this->view->version = $version;
                $this->view->level = $level;
                $this->view->authtype = $authtype;
                $this->view->authpass = $authpass;
                $this->view->privtype = $privtype;
                $this->view->privpass = $privpass;
                $this->view->version = $version;
                return;
            }
        }
    }

    #Fasiha: Added timeticks conversion

    function timeticks_convert( $timeticks ) {
        if ( $timeticks <= 0 ) {
            $ConvertSeconds = '0 Days - 0 Hours - 0 Mins - 0 Secs';
        } else {
            $lntSecs = intval( $timeticks / 100 );
            $intDays = intval( $lntSecs / 86400 );
            $intHours = intval( ( $lntSecs - ( $intDays * 86400 ) ) / 3600 );
            $intMinutes = intval( ( $lntSecs - ( $intDays * 86400 ) - ( $intHours * 3600 ) ) / 60 );
            $intSeconds = intval( ( $lntSecs - ( $intDays * 86400 ) - ( $intHours * 3600 ) - ( $intMinutes * 60 ) ) );
            $ConvertSeconds = "$intDays Days - $intHours Hours - $intMinutes Mins - $intSeconds Secs";
            $then = time() - ( ( $intDays*86400 ) + ( $intHours*3600 ) + ( $intMinutes*60 ) + $intSeconds );
            $uptimeDate = date( 'Y-m-d H:i', $then );
        }
        return $uptimeDate;
    }

    #Fasiha: Added vendor automatic identification function

    public function vendor( $identity ) {

        $vendor_array = array( 9 => 'cisco',
        11 => 'hp',
        35 => 'nortel',
        789 => 'netapp',
        1588 => 'brocade',
        3224 => 'netscreen',
        3375 => 'bigip',
        14501 => 'bluecoat',
        12325 => 'netsl',
        2011 => 'huawei',
        2636 => 'juniper',
        318 => 'apc',
        2021 => 'emerson',
        8886 => 'raisecom',
        12356 => 'fortinet',
        25053 => 'ruckus',
        4526 => 'netgear',
        1588 => 'brocade' );

        return $vendor_array[$identity];
    }

    #Fasiha: Added device Rediscovery feature

    public function devicesearchAction() {

        $hostname = $this->params->get( 'showHost' );
        $interfaces = array();
        $dbResourceName = Config::module( 'director' )->get( 'db', 'resource' );
        $connection = Db::fromResourceName( $dbResourceName );
        $db = $connection->getDbAdapter();
        $sql = "select ih.varvalue as 'snmp_version' ,h.address from icinga_host h
            inner join icinga_host_var ih on ih.host_id = h.id
            where ih.varname = 'snmp_version' and h.object_name = '$hostname'";
        //$sql = "select ih.varvalue, h.address from icinga_host h inner join icinga_host_var ih on ih.host_id = h.id where ih.varname = 'snmp_community' and h.object_name = '$hostname'";
        $hosts_version = $db->fetchAll( $sql );
        try {
            $version = $hosts_version[0]->snmp_version;
            if ( $version == -1 || $version == -2 ) {
                $sql = "select ih.varvalue as 'community',h.address from icinga_host h
                        inner join icinga_host_var ih on ih.host_id = h.id
                        where ih.varname = 'snmp_community' and h.object_name = '$hostname'";
                $hosts = $db->fetchAll( $sql );
                $hosts_arr = explode( ',', $hosts[0]->address );
                if ( $version == -1 ) {
                    try {
                        $session = new ss( ss::VERSION_1, $hosts_arr[0], $hosts[0]->community );
                    } catch( Exception $e ) {
                        $session = new ss( ss::VERSION_1, $hosts_arr[1], $hosts[0]->community );
                    }
                } else if ( $version == -2 ) {
                    try {
                        $session = new ss( ss::VERSION_2c, $hosts_arr[0], $hosts[0]->community );
                    } catch( Exception $e ) {
                        $session = new ss( ss::VERSION_2c, $hosts_arr[1], $hosts[0]->community );
                    }
                }
                try {
                    $snmpHost = new SNMP( $hosts_arr[0], $hosts[0]->community );
                } catch( Exception $e ) {
                    $snmpHost = new SNMP( $hosts_arr[1], $hosts[0]->community );
                }
                //                    $phys = $snmpHost->useIface()->descriptions();
            } else if ( $version == -3 ) {
                $sql = "select ih.varvalue as 'username', ih2.varvalue as 'level', 
                        ih3.varvalue as 'authtype', 
                        ih4.varvalue as 'authpass', 
                        ih5.varvalue as 'privtype', 
                        ih6.varvalue as 'privpass', 
                        h.address 
                        from icinga_host h
                        inner join icinga_host_var ih on ih.host_id = h.id
                        inner join icinga_host_var ih2 on ih2.host_id = h.id
                        inner join icinga_host_var ih3 on ih2.host_id = h.id
                        inner join icinga_host_var ih4 on ih2.host_id = h.id
                        inner join icinga_host_var ih5 on ih2.host_id = h.id
                        inner join icinga_host_var ih6 on ih2.host_id = h.id
                        where ih.varname = 'username' and ih2.varname = 'level'
                        and ih3.varname = 'authtype'
                        and ih4.varname = 'authpass'
                        and ih5.varname = 'privtype'
                        and ih6.varname = 'privpass'
                        and h.object_name = '$hostname'";
                $hosts = $db->fetchAll( $sql );
                $hosts_arr = explode( ',', $hosts[0]->address );
                try {
                    $session = new ss( ss::VERSION_3, $hosts_arr[0], $hosts[0]->username );
                    $session->setSecurity( $hosts[0]->level, $hosts[0]->authtype, $hosts[0]->authpass, $hosts[0]->privtype, $hosts[0]->privpass, '', '' );
                    $snmpHost = new SNMP( $hosts_arr[0], $hosts[0]->username, 3, $hosts[0]->level, $hosts[0]->authtype, $hosts[0]->authpass, $hosts[0]->privtype, $hosts[0]->privpass );
                } catch( Exception $e ) {
                    $session = new ss( ss::VERSION_3, $hosts_arr[1], $hosts[0]->username );
                    $session->setSecurity( $hosts[0]->level, $hosts[0]->authtype, $hosts[0]->authpass, $hosts[0]->privtype, $hosts[0]->privpass, '', '' );
                    $snmpHost = new SNMP( $hosts_arr[1], $hosts[0]->username, 3, $hosts[0]->level, $hosts[0]->authtype, $hosts[0]->authpass, $hosts[0]->privtype, $hosts[0]->privpass );
                }
                //                    $phys = $snmpHost->useIface()->names();
            }

            $ret = @$session->get( $this->oid_sysObjectID );
            $identity_arr = ( explode( '.', $ret ) );
            $identity = !empty( $identity_arr[7] ) ?  $identity_arr[7] : $identity_arr[1];
            try {
                $vendor = $this->vendor( $identity );
            } catch( Exception $e ) {
                $vendor = ' ';
            }
            $desc = @$session->get( $this->oid_sysDescr );
            $uptime = @$session->get( $this->oid_sysUpTime );
            $contact = @$session->get( $this->oid_sysContact );
            $sysname = @$session->get( $this->oid_sysName );
            $location = @$session->get( $this->oid_sysLocation );

            $model = ' ';
            $serial = ' ';
            $version = ' ';
            $whyreload = ' ';

            $time = strval ( $uptime );
            preg_match( '#\((.*?)\)#', $time, $match );
            $times = $match[1];
            $uptimes = $this->timeticks_convert( $times );
            //                foreach ( $phys as $key => $value ) {
            //                    array_push( $interfaces, $value );
            //                }
            if ( $vendor == 'cisco' ) {
                $chassis_model = @$session->get( $this->oid_cisco_ChassisModel );
                $chassis_serial = @$session->get( $this->oid_cisco_ChassisSrNumStr );
                $cisco_model = @$session->get( $this->oid_cisco_model );
                $cisco_serial = @$session->get( $this->oid_cisco_serial );
                $cisco_whyreload = @$session->get( $this->oid_cisco_whyreload );
                $cisco_software_revision = @$session->get( $this->oid_software_revision );
                $sw_rev = @$session->get( $this->oid_sw_rev );
                $cisco_switch_model = @$session->get( $this->oid_cisco_switch_model );
                $cisco_switch_serial = @$session->get( $this->oid_cisco_switch_serial );
                $cisco_switch_software_revision = @$session->get( $this->oid_cisco_switch_software_revision );

                $desc_version = explode( ',', $desc );
		$d_version = isset($desc[2])? $desc[2]: '';
                if ( !empty( $chassis_model ) and !empty( $chassis_serial ) ) {
                    $version = $sw_rev ?: $d_version;
                    $cisco_type = $chassis_model;
                    $serial = $chassis_serial;
                    $whyreload = $cisco_whyreload;
                    $model = $chassis_model;
                } else if ( !empty( $cisco_model ) and !empty( $cisco_serial ) ) {
                    $version = $cisco_software_revision ? : $d_version;
                    $cisco_type = $cisco_model;
                    $serial = $cisco_serial;
                    $whyreload = $cisco_whyreload;
                    $model = $cisco_model;

                } else if ( !empty( $cisco_switch_model ) and !empty( $cisco_switch_serial ) ) {
                    $version = $cisco_switch_software_revision;
                    $cisco_type = $cisco_switch_model;
                    $serial = $cisco_switch_serial;
                    $whyreload = ' ';
                    $model = $cisco_switch_model;
                }
            }
            if ( $vendor == 'apc' ) {
                $ups_model = @$session->get( $this->oid_apc_ups_model );
                $ups_serial = @$session->get( $this->oid_apc_ups_serial );
                $ups_rev = @$session->get( $this->oid_apc_ups_firmware_revision );
                $pdu_model = @$session->get( $this->oid_apc_pdu_model );
                $pdu_serial = @$session->get( $this->oid_apc_pdu_serial );
                $pdu_rev = @$session->get( $this->oid_apc_pdu_firmware_revision );
                if ( !empty( $ups_model ) and !empty( $ups_serial ) ) {
                    $model = $ups_model;
                    $serial = $ups_serial;
                    $version = $ups_rev;
                    $whyreload = ' ';
                }
                if ( !empty( $pdu_model ) and !empty( $pdu_serial ) ) {
                    $model = $pdu_model;
                    $serial = $pdu_serial;
                    $version = $pdu_rev;
                    $whyreload = ' ';

                }
            }
            if ( $vendor == 'juniper' ) {
                $juniper_model = @$session->get( $this->oid_juniper_model );
                $juniper_serial = @$session->get( $this->oid_juniper_serial );
                $juniper_version = @$session->get( $this->oid_juniper_version );
                $model = $juniper_model;
                $serial = $juniper_serial;
                $version = $juniper_version;
                $whyreload = ' ';
            }
            if ( $vendor == 'huawei' ) {
                $huawei_model = @$session->get( $this->oid_huawei_model );
                $huawei_serial = @$session->get( $this->oid_huawei_serial );
                $huawei_version = @$session->get( $this->oid_huawei_version );
                $model = $huawei_model;
                $serial = $huawei_serial;
                $version = $huawei_version;
                $whyreload = ' ';
            }

            if ( $vendor == 'fortinet' ) {
                $fortinet_serial = @$session->get( $this->oid_fortinet_serial );
                $fortinet_version = @$session->get( $this->oid_fortinet_version );
                $model = ' ';
                $serial = $fortinet_serial;
                $version = $fortinet_version;
                $whyreload = ' ';
            }

            if ( $vendor == 'raisecom' ) {
                $raisecom_model = @$session->get( $this->oid_raisecom_model );
                $raiseom_serial = @$session->get( $this->oid_raisecom_serial );
                $raisecom_version = @$session->get( $this->oid_raisecom_version );
                $model = $raisecom_model;
                $serial = $raiseom_serial;
                $version = str_replace( 'INTEGER:', '', $raisecom_version );
                $whyreload = ' ';
            }

            if ( $vendor == 'ruckus' ) {
                $ruckus_model = @$session->get( $this->oid_ruckus_model );
                $ruckus_serial = @$session->get( $this->oid_ruckus_serial );
                $ruckus_version = @$session->get( $this->oid_ruckus_version );
                $model = $ruckus_model;
                $serial = $ruckus_serial;
                $version = str_replace( 'INTEGER:', '', $ruckus_version );
                $whyreload = ' ';
            }

            if ( $vendor == 'brocade' ) {
                $brocade_model = @$session->get( $this->oid_brocade_model );
                $brocade_serial = @$session->get( $this->oid_brocade_serial );
                $brocade_version = @$session->get( $this->oid_brocade_version );
                $model = $brocade_model;
                $serial = $brocade_serial;
                $version = str_replace( 'INTEGER:', '', $brocade_version );
                $whyreload = ' ';
            }

            if ( $vendor == 'netgear' ) {
                $netgear_model = @$session->get( $this->oid_netgear_model );
                $netgear_serial = @$session->get( $this->oid_netgear_serial );
                $netgear_version = @$session->get( $this->oid_netgear_version );
                $model = $netgear_model;
                $serial = $netgear_serial;
                $version = str_replace( 'INTEGER:', '', $netgear_version );
                $whyreload = ' ';
            }
             if ( $vendor == 'hp' ) {
		     //$hp_model = @$session->get( $this->oid_hp_model );
		 $desc_model = explode( ',', $desc );
		 $hp_model = $desc_model[0];
                 $hp_serial = @$session->get( $this->oid_hp_serial );
                 $hp_version = @$session->get( $this->oid_hp_version );
                 $model = $hp_model;
                 $serial = $hp_serial;
                 $version = $hp_version ;
                 $whyreload = ' ';
             }
            $system_description = !empty( str_replace( '"', '', str_replace( 'STRING: ', '', $desc ) ) )? str_replace( '"', '', str_replace( 'STRING: ', '', $desc ) ): ' ';
            $system_name = !empty( str_replace( '"', '', str_replace( 'STRING: ', '', $sysname ) ) )? str_replace( '"', '', str_replace( 'STRING: ', '', $sysname ) ): ' ';
            $contact_info = !empty( str_replace( '"', '', str_replace( 'STRING: ', '', $contact ) ) )? str_replace( '"', '', str_replace( 'STRING: ', '', $contact ) ): ' ';
            $locations = !empty( str_replace( '"', '', str_replace( 'STRING: ', '', $location ) ) )? str_replace( '"', '', str_replace( 'STRING: ', '', $location ) ): ' ';
            $model_no = !empty( str_replace( '"', '', str_replace( 'STRING: ', '', $model ) ) ) ? str_replace( '"', '', str_replace( 'STRING: ', '', $model ) ) : ' ';
            $serial_no = !empty( str_replace( '"', '', str_replace( 'STRING: ', '', $serial ) ) ) ? str_replace( '"', '', str_replace( 'STRING: ', '', $serial ) ) : ' ';
            $version_no = !empty( str_replace( '"', '', str_replace( 'STRING: ', '', $version ) ) )?str_replace( '"', '', str_replace( 'STRING: ', '', $version ) ) : ' ';
            $why_reload = !empty( str_replace( '"', '', str_replace( 'STRING: ', '', $whyreload ) ) )?str_replace( '"', '', str_replace( 'STRING: ', '', $whyreload ) ) : ' ';
            $device_array = array();

            $url = $this->Config()->get( 'director', 'url' );
            $hostname_url = str_replace( ' ', '%20', str_replace( ',', '%2c', $hostname ) );
            $rq = RestRequest::post( "$url/director/host?name=".$hostname_url );
            //authentication username and password
            $rq->authenticateWith( $this->Config()->get( 'director', 'user' ), $this->Config()->get( 'director', 'password' ) );
            $mypayload = array(
                'vars.System Description'  => $system_description ,
                'vars.System Name' => $system_name,
                'vars.vendor_name' => $vendor,
                'vars.contact_info'=> $contact_info,
                'vars.location'=> $locations,
                'vars.reload_reason' => $why_reload ,
                'vars.Device Model' => $model_no,
                'vars.Software Version' => $version_no,
                'vars.Serial' => $serial_no
                //                     'vars.up_since' => $uptimes
                //                     'vars.interface_list' => $interfaces,
                //                     'vars.discovery_completed_at' => date( 'Y-m-d H:i:s', time() )
            );

            $mypayload = Json::encode( $mypayload, true );
            $rq->setPayload( $mypayload );
            $result = $rq->send();

            echo '&nbsp;&nbsp;Discovery Completed</br>';

	} catch( Exception $e ) {
		# print $e;
            echo '<p>&nbsp;SNMP might not be enabled on the host<br/></p>';
        }
    }

    public function monitoring() {
        if ( $this->monitoring === null ) {
            $this->monitoring = Backend::instance();
        }

        return $this->monitoring;
    }

    public function db() {
        if ( $this->db === null ) {
            $this->db = $this->monitoring()->getResource()->getDbAdapter();
        }
        return $this->db;
    }

    public function cdplldpdevicesearchAction() {
        $servicename = $this->params->get( 'servicename' );
        $host = $this->params->get( 'showHost' );
        $arr = explode( '!', $host );
        $hostname = $arr[0];
        $hostaddress = $arr[1];
        $result = $this->db()->fetchAll( $this->getQuery( $hostname, $servicename ) );

        $output = $result[0]->output;

        $this->view->output = $output;
        $this->view->host = $hostname;
        $this->view->servicename = $servicename;
        $this->view->hostaddress = $hostaddress;
        $this->render( 'formtest/device', null, true );

    }

    public function getQuery( $hostname, $servicename ) {

        $query = "select long_output as output from icinga_hosts h
        inner join icinga_services serv on h.host_object_id = serv.host_object_id
        inner join icinga_servicestatus servst on serv.service_object_id = servst.service_object_id
        where h.display_name = '$hostname' and serv.display_name = '$servicename'";

        return $query;
    }

}
