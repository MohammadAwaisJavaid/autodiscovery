<?php
namespace Icinga\Module\Autodiscovery\Forms;
//use Icinga\Module\Director\Web\Form\QuickForm;
use Icinga\Web\Form;
use Icinga\Web\Url;

class MyForm2 extends Form
{

    public function setup()
    {

      //input field ip address
       $this->addElement('text', 'ip', array(
        'required' => true,   
        'label' => $this->translate('Enter IP'),
        //'default' => '172.30.1.0/24',
          'pattern' => $this-> translate('^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])(\/(3[0-2]|[1-2][0-9]|[0-9]))$'),
        'placeholder'=> $this->translate('172.0.0.0/0')
    ));
     $ip=$this->getElement('ip');
     $ip->setValue('172.30.1.0/24');
    //input field community string
       $this->addElement('text', 'comm', 
       array(
        'required' => true,
           'label' => $this->translate('Community String'),
           'default' => 'public',
          'pattern' => $this-> translate('^[a-zA-Z0-9_]*$')
       ));
       $comm=$this->getElement('comm');
       $comm->setValue('public');
          //dropdown menu
          $this->addElement('select', 'version_type', array(
            'label'    => 'SNMP Version',
            'required' => true,
            'multiOptions' => array(
                'equal' => $this->translate('SNMP v1'),
                'flat'  => $this->translate('SNMP v2'),
                'straight'  => $this->translate('SNMP v3'),
            )
        ));
        
        //button display
       $this->setSubmitLabel('Next');
       $this->setProgressLabel($this->translate('Discovering Hosts'));
       $this->setAction("/trace9/autodiscovery/formtest/search2")->setMethod('post');
          
    }

    

}