<?php

namespace Icinga\Module\Autodiscovery\Forms\Config;

use Icinga\Forms\ConfigForm;

class BackendForm extends ConfigForm
{
    public function init()
    {
        $this->setName('form_config_autodiscovery_backend');
        $this->setSubmitLabel($this->translate('Save Changes'));
    }

    public function createElements(array $formData)
    {
        $this->addElements([
            [
                'text',
                'director_url',
                [
                    'required'      => true,
                    'label'         => $this->translate('Director Rest API URL'),
                    'description'   => $this->translate('URL to your Graphite Web'),
                    'validators'    => ['UrlValidator']
                ]
            ],
            [
                'text',
                'director_user',
                [
                    'label'         => $this->translate('Director Rest API User'),
                    'description'   => $this->translate(
                        'A user with access to your Director via HTTP basic authentication'
                    )
                ]
            ],
            [
                'password',
                'director_password',
                [
                    'renderPassword'    => true,
                    'label'             => $this->translate('Director Rest API password'),
                    'description'       => $this->translate('The above user\'s password')
                ]
            ]
        ]);
    }
}
