<?php
namespace Icinga\Module\Autodiscovery\Forms;
//use Icinga\Module\Director\Web\Form\QuickForm;
use Icinga\Web\Form;
use Icinga\Web\Url;

class MyForm3 extends Form
{

    public function setup()
    {

       $this->addElement('text', 'ip', array(
        'required' => true,
        'label' => $this->translate('Enter IP'),
        'default' => 'e.g 10.10.10.0',
        'description'   => $this->translate(
          'The target network address in CIDR format: a.b.c.0'
      )
    ));
     $ip=$this->getElement('ip');


          $this->addElement('select', 'version_type', array(
            'onchange' =>"snmpversionFunction()",
            'label'    => 'SNMP Version',
            'required' => true,
            'multiOptions' => array(
                '' => '',
                'v1'  => $this->translate('SNMP v1'),
                'v2' => $this->translate('SNMP v2'),
                'v3'  => $this->translate('SNMP v3'),
            )       ,
               'description'   => $this->translate(
              'Version 2 is compatible only.'
          )
        ));

    //input field community string
       $this->addElement('text', 'comm',
       array(
        'required' => false,
           'label' => $this->translate('Community String'),
           'default' => 'public',
           'pattern' => $this-> translate('^[a-zA-Z0-9_]*$'),
           'description'   => $this->translate(
             'Community String.'
         )
       ));

       $comm = $this->getElement('comm');
       $comm->setAttrib('disabled', 'disabled');

       $this->addElement('text', 'username',
       array(
        'required' => false,
           'label' => $this->translate('Username'),
           'default' => 'public',
          'pattern' => $this-> translate('^[a-zA-Z0-9_]*$'),
          'description'   => $this->translate(
            'Username.'
        )
       ));
       $username = $this->getElement('username');
       $username->setAttrib('disabled', 'disabled');


       $this->addElement('select', 'level', array(
           'label'    => 'Security Level',
           'required' => false,
           'multiOptions' => array(
               'noAuthnoPriv'  => $this->translate('noAuthnoPriv'),
               'authNoPriv' => $this->translate('authNoPriv'),
               'authPriv' => $this->translate('authPriv'),
           )       ,
           'description'   => $this->translate(
               'Security Level.'
           )
       ));

       $level = $this->getElement('level');
       $level->setAttrib('disabled', 'disabled');


          $this->addElement('select', 'authtype', array(
            'label'    => 'Authentication Protocol',
            'required' => false,
            'multiOptions' => array(
              'MD5'  => $this->translate('MD5'),
              'SHA' => $this->translate('SHA'),
            )       ,
               'description'   => $this->translate(
              'Authentication Protocol.'
          )
        ));

       $authtype = $this->getElement('authtype');
       $authtype->setAttrib('disabled', 'disabled');


       $this->addElement('select', 'privtype', array(
            'label'    => 'Privacy protocol',
            'required' => false,
            'multiOptions' => array(
              'AES'  => $this->translate('AES'),
              'DES' => $this->translate('DES'),
            )       ,
               'description'   => $this->translate(
              'Privacy Protocol.'
          )
        ));

       $privtype = $this->getElement('privtype');
       $privtype->setAttrib('disabled', 'disabled');


       $this->addElement('text', 'authpass',
       array(
        'required' => false,
        'label' => $this->translate('Authentication Passphrase'),
//        'pattern' => $this-> translate('^[a-zA-Z0-9_]*$'),
        'description'   => $this->translate(
        'Authentication passphrase.'
        )
       ));

       $authpass = $this->getElement('authpass');
       $authpass->setAttrib('disabled', 'disabled');


       $this->addElement('text', 'privpass',
       array(
        'required' => false,
        'label' => $this->translate('Privacy Passphrase'),
  //      'pattern' => $this-> translate('^[a-zA-Z0-9_]*$'),
        'description'   => $this->translate(
        'Privacy passphrase.'
        )
       ));

       $privpass = $this->getElement('privpass');
       $privpass->setAttrib('disabled', 'disabled');

       $this->setSubmitLabel('Scan network');
       $this->setProgressLabel($this->translate('Discovering Hosts'));
       $this->setAction("/trace9/autodiscovery/formtest/cdpsearch")->setMethod('post');

    }



}
?>

<script type="text/JavaScript">

function snmpversionFunction() {
  var x = document.getElementsByName("version_type")[0].value;
  if(x == 'v3'){
      document.getElementsByName("username")[0].disabled = false;
      document.getElementsByName("username")[0].setAttribute('required','true');
      document.getElementsByName("comm")[0].disabled = true;
      document.getElementsByName("authpass")[0].disabled = false;
      document.getElementsByName("authpass")[0].setAttribute('required','true');
      document.getElementsByName("privpass")[0].disabled = false;
      document.getElementsByName("privpass")[0].setAttribute('required','true');
      document.getElementsByName("level")[0].disabled = false;
      document.getElementsByName("level")[0].setAttribute('required','true');
      document.getElementsByName("authtype")[0].disabled = false;
      document.getElementsByName("authtype")[0].setAttribute('required','true');
      document.getElementsByName("privtype")[0].disabled = false;
      document.getElementsByName("privtype")[0].setAttribute('required','true');

  }else if(x == 'v2' || x == 'v1'){
      document.getElementsByName("username")[0].disabled = true;
      document.getElementsByName("comm")[0].disabled = false;
      document.getElementsByName("comm")[0].setAttribute('required','true');
      document.getElementsByName("authpass")[0].disabled = true;
      document.getElementsByName("privpass")[0].disabled = true;
      document.getElementsByName("level")[0].disabled = true;
      document.getElementsByName("authtype")[0].disabled = true;
      document.getElementsByName("privtype")[0].disabled = true;
  }
}

</script>

