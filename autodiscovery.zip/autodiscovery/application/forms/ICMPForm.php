<?php
namespace Icinga\Module\Autodiscovery\Forms;
//use Icinga\Module\Director\Web\Form\QuickForm;
use Icinga\Web\Form;
use Icinga\Web\Url;


class ICMPForm extends Form
{

    public function setup()
    {

      //input field ip address
       $this->addElement('text', 'ip', array(
        'required' => true,
        'label' => $this->translate('Enter IP'),
 'pattern' => $this-> translate('^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$'),
        'default' => 'e.g 10.10.10.0',
        'description'   => $this->translate(
          'The target network address in CIDR format: a.b.c.0'
      )
     ));
       $ip=$this->getElement('ip');

       $this->addElement('select', 'mask_bits', array(
            'label'    => 'Mask Bits',
            'required' => true,
            'multiOptions' => array(
                '' => '',
                '24'  => '24',
                '25' =>  '25',
                '26'  => '26',
                '27' => '27',
                '28' => '28',
                '29'  => '29',
                '30' => '30'
            )       ,
               'description'   => $this->translate(
              'Mask Bits .'
          )
        ));


       //button display
       $this->setSubmitLabel('Scan network');
       $this->setProgressLabel($this->translate('Discovering Hosts'));
       $this->setAction("/trace9/autodiscovery/formtest/searchicmp")->setMethod('post');
          
    }

    

}
?>

