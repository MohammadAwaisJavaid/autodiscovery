# icingaweb2-module-autodiscovery



#TODOS:-
1) Fetch the Host template select list from the database of your icingaweb2.
2) Host add User experience



Dependencies:-
1) yum install nmap
2) yum install rh-php71-php-snmp

