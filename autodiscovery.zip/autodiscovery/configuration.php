<?php

//sidemenu 
$section = $this->menuSection(N_('Auto Discovery'), array(
    'icon'      => 'host',
    'priority'  => 30
));

//SNMP icon
$section->add(N_('Hosts'), array(
    'icon'        => 'chart-line',
    'description' => $this->translate('Discover hosts'),
    'url'         => '/trace9/autodiscovery/formtest',
    'priority'    => 40
));

//interface icon
$section->add(N_('Interface'), array(
    'icon'        => 'chart-line',
    'description' => $this->translate('Discover Interface'),
    'url'         => '/trace9/autodiscovery/formtest/interface',
    'priority'    => 40
));

//CDP icon
$section->add(N_('CDP'), array(
    'icon'        => 'chart-line',
    'description' => $this->translate('Discover devices via CDP protocol'),
    'url'         => '/trace9/autodiscovery/formtest/cdp',
    'priority'    => 60
));

$this->provideConfigTab('backend', array(
    'title' => $this->translate('Configure the backend'),
    'label' => $this->translate('Backend'),
    'url' => 'config/backend'
));

//LLDP icon
$section->add(N_('LLDP'), array(
    'icon'        => 'chart-line',
    'description' => $this->translate('Discover devices via LLDP protocol'),
    'url'         => '/trace9/autodiscovery/formtest/lldp',
    'priority'    => 60
));

//ICMP icon
$section->add(N_('ICMP'), array(
    'icon'        => 'chart-line',
    'description' => $this->translate('Discover devices via NMAP protocol'),
    'url'         => '/trace9/autodiscovery/formtest/icmp',
    'priority'    => 60
));



// // interface icon
// $section->add(N_('SNMP dev'), array(
//     'icon'        => 'chart-line',
//     'description' => $this->translate('Discover hosts dev'),
//     'url'         => 'autodiscovery/formtest/snmp2',
//     'priority'    => 41
// ));


$this->provideCssFile('vendor/vis-network.min.css');
$this->provideJsFile('vendor/vis.js');
$this->provideJsFile('vendor/php-unserialize.js');

