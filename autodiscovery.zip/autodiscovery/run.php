<?php

$this->provideHook('monitoring/HostActions');
$this->provideHook('monitoring/ServiceActions');

//require_once __DIR__ . '/library/Autodiscovery/ProvidedHook/Monitoring/HostActions.php';
require_once __DIR__ . '/library/Autodiscovery/ProvidedHook/Monitoring/ServiceActions.php';
